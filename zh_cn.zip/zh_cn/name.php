<?php
/**
 * Multicraft 2.X 简体中文翻译 2.0
 * Multicraft 2.X Simplified Chinese translation 2.0
 *
 * By Neveark.
 * E-mail:alprenx@gmail.com
 *
 * 注意, 必须以 UTF-8 格式保存此文件。
 * NOTE, this file must be saved in UTF-8 encoding.
 */
return array (
    'short'=>'zh_cn',    //语言代码，如"de"
    'english'=>'Simplified Chinese',  //语言的英文名
    'local'=>'中文(简体)',    //在此语言中的语言名称
);
